"""Reproduce every simulation result, table and figure reported in the manuscript.

Usage:  python -m experiments.run_all
Outputs: results/results.json, results/tables/*.csv, results/figures/*.png and *.pdf

All results here are SIMULATION results under the stated generative assumptions. They are
design-analysis results, not measurements on real signers or counters.
"""
from __future__ import annotations
import json
import time
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from setu.calibration import (PlattScaler, TemperatureScaler, brier, ece, logit, nll,
                              reliability_table, sigmoid)
from setu.queueing import (erlang_c, exponential_sampler, lognormal_sampler, max_counters,
                           p_wait_exceeds, simulate_mgc)
from setu.readback import simulate_sessions
from setu.trust_gate import CostModel, K, tau_star

ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / "results"
FIG = RES / "figures"
TAB = RES / "tables"
FIG.mkdir(parents=True, exist_ok=True)
TAB.mkdir(parents=True, exist_ok=True)

SEED = 20261113
BASE = dict(a=0.90, m=1.0)           # turn-level accuracy and class separation
CM = CostModel()                      # baseline costs
R = 100                               # Monte Carlo replications
N_TEST = 20_000
N_VAL = 2_000

plt.rcParams.update({"font.family": "sans-serif", "font.sans-serif": ["Inter", "DejaVu Sans"],
                     "font.size": 9, "axes.titlesize": 9, "axes.labelsize": 9, "legend.fontsize": 8,
                     "xtick.labelsize": 8, "ytick.labelsize": 8, "figure.dpi": 150,
                     "axes.spines.top": False, "axes.spines.right": False,
                     "axes.edgecolor": "#52514e", "axes.labelcolor": "#0b0b0b", "text.color": "#0b0b0b",
                     "xtick.color": "#52514e", "ytick.color": "#52514e"})
# Categorical colours (blue, orange, violet, green) pass the colour-vision separation checks of the dataviz validator.
C_BLUE, C_ORANGE, C_VIOLET, C_GREEN, C_GRAY = "#2a78d6", "#eb6834", "#6250d6", "#008300", "#5F5E5A"
# kept for backward compatibility with earlier versions of this script
C_TEAL, C_CORAL, C_PURPLE, C_AMBER = C_BLUE, C_ORANGE, C_VIOLET, C_GREEN
PALETTE = [C_BLUE, C_ORANGE, C_VIOLET, C_GREEN, C_GRAY]
# Ordered quantity (read-back detection probability d): one hue, light to dark.
SEQ_BLUES = ["#9ec5f4", "#6aa3e8", "#3f86dc", "#2262b0", "#12437d"]


def panel_label(ax, text):
    ax.text(-0.02, 1.06, text, transform=ax.transAxes, fontsize=10, fontweight="bold", va="bottom", ha="left")


def savefig(fig, name):
    fig.savefig(FIG / f"{name}.png", dpi=300, bbox_inches="tight", facecolor="white")
    fig.savefig(FIG / f"{name}.pdf", bbox_inches="tight", facecolor="white")
    plt.close(fig)


def gen_turns(n, a, m, rng):
    """Latent-score model: y ~ Bernoulli(a); s | y ~ N((2y-1) m, 1).
    The calibrated confidence is sigmoid(2 m s + logit(a)) (log-likelihood ratio for equal-variance Gaussians)."""
    y = (rng.random(n) < a).astype(int)
    s = rng.normal((2 * y - 1) * m, 1.0)
    c_true = sigmoid(2 * m * s + logit(a))
    return y, s, c_true


def auroc(m):
    from scipy.stats import norm
    return float(norm.cdf(np.sqrt(2) * m))


def pct(x):
    x = np.asarray(x, dtype=float)
    return float(np.mean(x)), float(np.percentile(x, 2.5)), float(np.percentile(x, 97.5))


def fmt(t, d=3):
    return f"{t[0]:.{d}f} [{t[1]:.{d}f}, {t[2]:.{d}f}]"


def turn_outcomes(y, esc, cm, readback=True):
    """Expected residual error and cost per turn given realised correctness y and escalation flags.
    Expectation is taken over the citizen's detection draw (prob d) and the interpreter's accuracy (a_h)."""
    p_wrong = np.where(esc, 1.0 - cm.a_h, 1.0 - y)
    if readback:
        resid = p_wrong * (1.0 - cm.d)
        cost = cm.C_rb + p_wrong * K(cm) + esc * cm.C_e
    else:
        resid = p_wrong
        cost = p_wrong * cm.C_w + esc * cm.C_e
    return resid, cost


def main():
    t0 = time.time()
    ss = np.random.SeedSequence(SEED)
    seeds = ss.spawn(10)
    out = {"seed": SEED, "replications": R, "n_test": N_TEST, "n_val": N_VAL,
           "baseline": {**BASE, "auroc": auroc(BASE["m"]), **CM.__dict__, "tau_star": tau_star(CM)}}

    # ------------------------------------------------------------------ E1 calibration
    rng = np.random.default_rng(seeds[0])
    rows = []
    kappas = [1.0, 1.5, 2.5, 4.0]
    tau_b = tau_star(CM)
    keep = {}
    for kappa in kappas:
        acc = {k: [] for k in ["raw_ece", "T_ece", "P_ece", "raw_brier", "P_brier", "raw_nll", "P_nll",
                               "raw_esc", "T_esc", "P_esc", "O_esc", "raw_res", "T_res", "P_res", "O_res",
                               "raw_cost", "T_cost", "P_cost", "O_cost", "T_hat"]}
        for r in range(R):
            yv, sv, _ = gen_turns(N_VAL, BASE["a"], BASE["m"], rng)
            yt, st, ct = gen_turns(N_TEST, BASE["a"], BASE["m"], rng)
            lv = kappa * (2 * BASE["m"] * sv + logit(BASE["a"]))
            lt = kappa * (2 * BASE["m"] * st + logit(BASE["a"]))
            ts = TemperatureScaler().fit(lv, yv)
            ps = PlattScaler().fit(lv, yv)
            conf = {"raw": sigmoid(lt), "T": ts.transform(lt), "P": ps.transform(lt), "O": ct}
            for k, c in conf.items():
                esc = (c < tau_b).astype(float)
                res, cost = turn_outcomes(yt, esc, CM)
                acc[f"{k}_esc"].append(esc.mean()); acc[f"{k}_res"].append(res.mean()); acc[f"{k}_cost"].append(cost.mean())
            acc["raw_ece"].append(ece(yt, conf["raw"])); acc["T_ece"].append(ece(yt, conf["T"])); acc["P_ece"].append(ece(yt, conf["P"]))
            acc["raw_brier"].append(brier(yt, conf["raw"])); acc["P_brier"].append(brier(yt, conf["P"]))
            acc["raw_nll"].append(nll(yt, conf["raw"])); acc["P_nll"].append(nll(yt, conf["P"]))
            acc["T_hat"].append(ts.T)
            if r == 0 and kappa == 2.5:
                keep = {"y": yt, "raw": conf["raw"], "P": conf["P"]}
        for k, v in acc.items():
            out.setdefault("E1", {}).setdefault(str(kappa), {})[k] = pct(v)
        rows.append({"overconfidence_kappa": kappa,
                     "ECE raw": fmt(out["E1"][str(kappa)]["raw_ece"]), "ECE temp": fmt(out["E1"][str(kappa)]["T_ece"]),
                     "ECE Platt": fmt(out["E1"][str(kappa)]["P_ece"]),
                     "Esc. rate raw": fmt(out["E1"][str(kappa)]["raw_esc"]), "Esc. rate Platt": fmt(out["E1"][str(kappa)]["P_esc"]),
                     "Esc. rate oracle": fmt(out["E1"][str(kappa)]["O_esc"]),
                     "Residual raw": fmt(out["E1"][str(kappa)]["raw_res"], 4), "Residual Platt": fmt(out["E1"][str(kappa)]["P_res"], 4),
                     "Residual oracle": fmt(out["E1"][str(kappa)]["O_res"], 4),
                     "Cost raw": fmt(out["E1"][str(kappa)]["raw_cost"], 3), "Cost Platt": fmt(out["E1"][str(kappa)]["P_cost"], 3),
                     "Cost oracle": fmt(out["E1"][str(kappa)]["O_cost"], 3), "T_hat": fmt(out["E1"][str(kappa)]["T_hat"], 2)})
    pd.DataFrame(rows).to_csv(TAB / "table_calibration.csv", index=False)

    fig, axes = plt.subplots(1, 2, figsize=(6.6, 3.1), sharey=True)
    for ax, key, title, col in [(axes[0], "raw", "(a) Raw confidence ($\\kappa$ = 2.5)", C_ORANGE), (axes[1], "P", "(b) After Platt scaling", C_BLUE)]:
        cen, conf, accu, cnt = reliability_table(keep["y"], keep[key], 15)
        ok = cnt > 0
        ax.plot([0, 1], [0, 1], "--", color=C_GRAY, lw=1, zorder=1)
        ax.plot(conf[ok], accu[ok], color=col, lw=1.1, alpha=0.8, zorder=2)
        ax.scatter(conf[ok], accu[ok], s=14 + 46 * np.sqrt(cnt[ok] / cnt.max()), color=col, edgecolor="white", linewidth=0.8,
                   zorder=3, clip_on=False)
        ax.set_title(title, loc="left", pad=8); ax.set_xlabel("Mean predicted confidence")
        ax.set_xlim(-0.03, 1.03); ax.set_ylim(-0.03, 1.03); ax.set_aspect("equal", adjustable="box")
        ax.text(0.97, 0.06, f"ECE = {ece(keep['y'], keep[key]):.3f}", transform=ax.transAxes, ha="right", va="bottom",
                bbox=dict(boxstyle="round,pad=0.25", fc="white", ec="#d3d2cd", lw=0.6))
    axes[0].set_ylabel("Observed accuracy")
    fig.tight_layout(w_pad=1.5)
    savefig(fig, "fig_reliability")

    # ------------------------------------------------------------------ E2 policy comparison
    rng = np.random.default_rng(seeds[1])
    pol_rows, pol_json = [], {}
    tau_gate = CM.a_h - CM.C_e / CM.C_w            # gate-only optimum (no read-back)
    for m in [0.75, 1.0, 1.5]:
        acc = {p: {"res": [], "esc": [], "cost": []} for p in ["P0", "P1", "P2", "P3", "P4"]}
        for r in range(R):
            y, s, c = gen_turns(N_TEST, BASE["a"], m, rng)
            z = np.zeros(N_TEST); o = np.ones(N_TEST)
            for p, (esc, rb) in {"P0": (z, False), "P1": ((c < tau_gate).astype(float), False), "P2": (z, True),
                                 "P3": ((c < tau_star(CM)).astype(float), True), "P4": (o, False)}.items():
                res, cost = turn_outcomes(y, esc, CM, readback=rb)
                acc[p]["res"].append(res.mean()); acc[p]["esc"].append(esc.mean()); acc[p]["cost"].append(cost.mean())
        names = {"P0": "P0 Auto-accept", "P1": "P1 Gate only", "P2": "P2 Read-back only", "P3": "P3 Setu (gate + read-back)", "P4": "P4 Always escalate"}
        for p in acc:
            res, esc, cost = pct(acc[p]["res"]), pct(acc[p]["esc"]), pct(acc[p]["cost"])
            pol_json.setdefault(str(m), {})[p] = {"residual": res, "escalation": esc, "cost": cost}
            pol_rows.append({"AUROC": round(auroc(m), 3), "Policy": names[p], "Residual wrong-submission rate": fmt(res, 4),
                             "Escalation rate": fmt(esc, 3), "Mean cost per turn": fmt(cost, 2)})
    out["E2"] = pol_json
    out["E2_tau_gate_only"] = tau_gate
    pd.DataFrame(pol_rows).to_csv(TAB / "table_policies.csv", index=False)

    # ------------------------------------------------------------------ E3 threshold validation and risk tiers
    rng = np.random.default_rng(seeds[2])
    grid = np.round(np.arange(0.0, 1.0001, 0.005), 3)
    d_list = [0.0, 0.5, 0.8, 0.9, 0.95]
    cw_list = {"low (C_w=10)": 10.0, "medium (C_w=100)": 100.0, "high (C_w=1000)": 1000.0}
    big = [gen_turns(200_000, BASE["a"], BASE["m"], rng) for _ in range(10)]
    thr_rows, thr_json = [], {}
    for rname, cw in cw_list.items():
        for d in d_list:
            cm = CM.with_(C_w=cw, d=d)
            ts_ = tau_star(cm)
            emp, regret, qv = [], [], []
            for y, s, c in big:
                order = np.argsort(c)
                cs, ys = c[order], y[order]
                cum_wrong = np.concatenate([[0.0], np.cumsum(1 - ys)])      # wrong among the first i (escalated) turns
                tot_wrong = (1 - ys).sum()
                n = len(c)
                idx = np.searchsorted(cs, grid, side="left")                 # number escalated at each tau (c < tau)
                esc_cost = idx * (cm.C_e + cm.C_rb + (1 - cm.a_h) * K(cm))
                acc_cost = (n - idx) * cm.C_rb + (tot_wrong - cum_wrong[idx]) * K(cm)
                cost = (esc_cost + acc_cost) / n
                j = int(np.argmin(cost)); emp.append(grid[j])
                jt = int(np.searchsorted(grid, ts_))
                jt = min(jt, len(grid) - 1)
                regret.append((cost[jt] - cost[j]) / cost[j])
                qv.append(np.mean(c < ts_))
            thr_json.setdefault(rname, {})[str(d)] = {"tau_star": ts_, "tau_empirical_mean": float(np.mean(emp)),
                                                      "tau_empirical_sd": float(np.std(emp)), "regret_pct": float(100 * np.mean(regret)),
                                                      "q_at_tau_star": float(np.mean(qv))}
            thr_rows.append({"Risk class": rname, "d": d, "tau* (closed form)": round(ts_, 3),
                             "tau (empirical argmin)": f"{np.mean(emp):.3f} ({np.std(emp):.3f})",
                             "Regret at tau* (%)": round(100 * float(np.mean(regret)), 3),
                             "Escalation rate at tau*": round(float(np.mean(qv)), 3)})
    out["E3"] = thr_json
    pd.DataFrame(thr_rows).to_csv(TAB / "table_threshold.csv", index=False)

    dd = np.linspace(0, 0.99, 100)
    thr_curves = {rname: [tau_star(CM.with_(C_w=cw, d=x)) for x in dd] for rname, cw in cw_list.items()}
    RISK_LABEL = {"low (C_w=10)": "Low risk ($C_w$ = 10)", "medium (C_w=100)": "Medium risk ($C_w$ = 100)", "high (C_w=1000)": "High risk ($C_w$ = 1000)"}
    def draw_threshold(ax):
        for (rname, cw), col, mk in zip(cw_list.items(), [C_GREEN, C_BLUE, C_ORANGE], ["s", "o", "^"]):
            ax.plot(dd, thr_curves[rname], color=col, lw=1.6, label=RISK_LABEL[rname])
            ax.errorbar(d_list, [thr_json[rname][str(x)]["tau_empirical_mean"] for x in d_list],
                        yerr=[thr_json[rname][str(x)]["tau_empirical_sd"] for x in d_list], fmt=mk, ms=4.5, mfc="white",
                        mec=col, color=col, capsize=2, elinewidth=0.9, zorder=4)
        ax.set_xlabel("Read-back detection probability $d$"); ax.set_ylabel("Escalation threshold $\\tau$")
        ax.set_xlim(-0.02, 1.0); ax.set_ylim(-0.03, 1.03); ax.grid(alpha=0.2)
        ax.legend(frameon=False, loc="center left", bbox_to_anchor=(0.02, 0.70), fontsize=7.5, handlelength=1.6)

    # ------------------------------------------------------------------ E4 Pareto frontier and risk-coverage
    rng = np.random.default_rng(seeds[3])
    y, s, c = gen_turns(400_000, BASE["a"], BASE["m"], rng)
    order = np.argsort(c); cs, ys = c[order], y[order]
    n = len(c); cum_wrong = np.concatenate([[0.0], np.cumsum(1 - ys)]); tot_wrong = (1 - ys).sum()
    taus = np.linspace(0, 1, 401)
    idx = np.searchsorted(cs, taus, side="left")
    esc_rate = idx / n
    pareto, pareto_curves = {}, []
    for d, col in zip([0.0, 0.5, 0.8, 0.9, 0.95], SEQ_BLUES):
        resid = (idx * (1 - CM.a_h) + (tot_wrong - cum_wrong[idx])) / n * (1 - d)
        t = tau_star(CM.with_(d=d)); j = int(np.searchsorted(cs, t))
        pt = (j / n, (j * (1 - CM.a_h) + (tot_wrong - cum_wrong[j])) / n * (1 - d))
        pareto_curves.append((d, col, resid, pt))
        pareto[str(d)] = {"tau_star": t, "escalation": pt[0], "residual": float(pt[1])}
    def draw_pareto(ax):
        for d, col, resid, pt in pareto_curves:
            ax.plot(esc_rate, np.maximum(resid, 1e-4), color=col, lw=1.6, label=f"$d$ = {d:g}")
            ax.plot(*pt, "o", color="white", mec=col, mew=1.6, ms=5.5, zorder=4)
        ax.set_xlabel("Escalation rate"); ax.set_ylabel("Residual wrong-submission rate"); ax.set_yscale("log")
        ax.set_xlim(0, 1); ax.set_ylim(3e-4, 0.5); ax.grid(alpha=0.2, which="major")
        ax.legend(frameon=False, loc="upper right", fontsize=7.5, ncol=1)
    out["E4_pareto_points"] = pareto

    fig, ax = plt.subplots(figsize=(3.4, 2.9))
    rc = {}
    for m, col in zip([0.75, 1.0, 1.5], [C_ORANGE, C_BLUE, C_VIOLET]):
        yy, ss_, cc = gen_turns(400_000, BASE["a"], m, rng)
        o = np.argsort(-cc); yo = yy[o]
        cov = np.arange(1, len(yo) + 1) / len(yo)
        risk = np.cumsum(1 - yo) / np.arange(1, len(yo) + 1)
        sel = np.linspace(0.05, 1.0, 120); ii = (sel * len(yo)).astype(int) - 1
        ax.plot(sel, risk[ii], color=col, lw=1.4, label=f"AUROC {auroc(m):.2f}")
        rc[str(m)] = {"risk_at_cov_0.7": float(risk[int(0.7 * len(yo)) - 1]), "risk_at_cov_0.9": float(risk[int(0.9 * len(yo)) - 1]),
                      "aurc": float(np.trapezoid(risk[::1000], cov[::1000]))}
    ax.set_xlabel("Coverage (fraction of turns accepted)"); ax.set_ylabel("Selective risk (error among accepted)")
    ax.legend(frameon=False); ax.set_ylim(0, 0.11)
    savefig(fig, "fig_risk_coverage")
    out["E4_risk_coverage"] = rc

    # ------------------------------------------------------------------ E5 interpreter-hub capacity
    n_t, ES, T_SLA, EPS = 4.0, 60.0, 20.0, 0.05
    out["E5_params"] = {"turns_per_transaction": n_t, "mean_service_s": ES, "sla_wait_s": T_SLA, "sla_exceed_prob": EPS}
    cap_rows, cap_json = [], {}
    for d in [0.5, 0.8, 0.9, 0.95]:
        q = thr_json["medium (C_w=100)"][str(d)]["q_at_tau_star"]
        for lam in [1, 2, 4, 6]:
            for cpool in [2, 3, 4]:
                N = max_counters(cpool, lam, n_t, q, ES, T_SLA, EPS)
                cap_json.setdefault(str(d), {}).setdefault(str(lam), {})[str(cpool)] = {"q": q, "max_counters": N, "per_interpreter": N / cpool}
                cap_rows.append({"d": d, "Escalation rate q": round(q, 3), "Transactions per counter-hour": lam,
                                 "Interpreters in pool": cpool, "Max counters served": N, "Counters per interpreter": round(N / cpool, 1)})
    out["E5"] = cap_json
    pd.DataFrame(cap_rows).to_csv(TAB / "table_capacity.csv", index=False)

    qs = np.linspace(0.02, 0.8, 40)
    def draw_capacity(ax):
        for lam, col, ls in zip([1, 2, 4, 6], [C_BLUE, C_GREEN, C_VIOLET, C_ORANGE], ["-", "--", "-.", ":"]):
            ax.plot(qs, [max_counters(3, lam, n_t, q, ES, T_SLA, EPS) / 3 for q in qs], color=col, lw=1.6, ls=ls,
                    label=f"$\\lambda$ = {lam}")
        ax.axhline(8, color=C_GRAY, ls="-", lw=0.9, alpha=0.8, label="8:1 design target")
        ax.set_yscale("log"); ax.set_xlabel("Escalation rate $q$"); ax.set_ylabel("Counters per interpreter (pool of 3)")
        ax.set_xlim(0, 0.8); ax.set_ylim(0.8, 2500); ax.grid(alpha=0.2, which="major")
        ax.legend(frameon=False, fontsize=7.5, loc="upper right", title="Transactions per counter-hour", title_fontsize=7.5)

    # combined effect of read-back on threshold, escalation and capacity
    fig, axes = plt.subplots(1, 3, figsize=(6.6, 2.4))
    dv = np.array([0.0, 0.3, 0.5, 0.7, 0.8, 0.9, 0.95])
    cmv = [CM.with_(d=x) for x in dv]
    big_c = np.sort(big[0][2])
    tv = np.array([tau_star(x) for x in cmv]); qv = np.searchsorted(big_c, tv) / len(big_c)
    axes[0].plot(dv, tv, "o-", color=C_BLUE, ms=4, lw=1.5); axes[0].set_xlabel("$d$"); axes[0].set_ylabel("Threshold $\\tau^*$")
    axes[1].plot(dv, qv, "o-", color=C_ORANGE, ms=4, lw=1.5); axes[1].set_xlabel("$d$"); axes[1].set_ylabel("Escalation rate")
    ratio = [max_counters(3, 2, n_t, max(q, 1e-3), ES, T_SLA, EPS) / 3 for q in qv]
    axes[2].plot(dv, ratio, "o-", color=C_VIOLET, ms=4, lw=1.5); axes[2].set_xlabel("$d$"); axes[2].set_ylabel("Counters per interpreter")
    for a_, t_ in zip(axes, ["(a)", "(b)", "(c)"]): panel_label(a_, t_)
    for a_ in axes: a_.grid(alpha=0.25)
    fig.tight_layout(w_pad=1.2); savefig(fig, "fig_readback_effect")
    out["E5_readback_effect"] = {"d": dv.tolist(), "tau_star": tv.tolist(), "q": qv.tolist(), "counters_per_interpreter_lambda2_pool3": ratio}

    # ------------------------------------------------------------------ E6 DES validation
    c_pool, ES = 3, 60.0
    des_rows, des_json = [], {}
    t_axis = np.linspace(0, 120, 61)
    des_curves = []
    for rho, col in zip([0.5, 0.7, 0.85], [C_GREEN, C_BLUE, C_ORANGE]):
        A = rho * c_pool
        lam_s = A / ES
        an = [p_wait_exceeds(A, c_pool, ES, t) for t in t_axis]
        sim_pts = None
        for label, sampler in [("exp", exponential_sampler(ES)), ("lognormal CV=0.5", lognormal_sampler(ES, 0.5)), ("lognormal CV=1.5", lognormal_sampler(ES, 1.5))]:
            w = simulate_mgc(lam_s, c_pool, 300_000, sampler, seed=int(rho * 1000) + len(label))
            w = w[20_000:]                                  # discard warm-up
            des_p20 = float(np.mean(w > 20.0)); an20 = p_wait_exceeds(A, c_pool, ES, 20.0)
            des_json.setdefault(str(rho), {})[label] = {"des_p_gt_20s": des_p20, "erlang_c_p_gt_20s": an20, "des_mean_wait_s": float(w.mean())}
            des_rows.append({"Utilisation rho": rho, "Service time": label, "Erlang C P(W>20 s)": round(an20, 4),
                             "Simulated P(W>20 s)": round(des_p20, 4), "Simulated mean wait (s)": round(float(w.mean()), 2)})
            if label == "exp":
                ts_ = np.linspace(0, 120, 25)
                sim_pts = (ts_, [np.mean(w > t) for t in ts_])
        des_curves.append((rho, col, an, sim_pts))
    def draw_des(ax):
        for rho, col, an, sim_pts in des_curves:
            ax.plot(t_axis, an, color=col, lw=1.6, label=f"$\\rho$ = {rho}")
            ax.plot(*sim_pts, "o", color="white", mec=col, mew=1.1, ms=3.6, zorder=4)
        ax.plot([], [], "o", color="white", mec=C_GRAY, mew=1.1, ms=3.6, label="simulation")
        ax.set_xlabel("Waiting-time threshold $t$ (s)"); ax.set_ylabel("$P(W>t)$"); ax.set_yscale("log"); ax.set_ylim(1e-4, 1)
        ax.set_xlim(0, 120); ax.grid(alpha=0.2, which="major")
        ax.legend(frameon=False, fontsize=7.5, loc="lower left", title="Erlang C (lines)", title_fontsize=7.5)
    # composite figures used in the manuscript
    fig, axes = plt.subplots(1, 2, figsize=(6.6, 2.9))
    draw_threshold(axes[0]); draw_pareto(axes[1]); panel_label(axes[0], "(a)"); panel_label(axes[1], "(b)")
    fig.tight_layout(w_pad=1.8); savefig(fig, "fig_threshold_frontier")
    fig, axes = plt.subplots(1, 2, figsize=(6.6, 2.9))
    draw_capacity(axes[0]); draw_des(axes[1]); panel_label(axes[0], "(a)"); panel_label(axes[1], "(b)")
    fig.tight_layout(w_pad=1.8); savefig(fig, "fig_capacity_des")
    out["E6"] = des_json
    pd.DataFrame(des_rows).to_csv(TAB / "table_des.csv", index=False)

    # ------------------------------------------------------------------ E7 read-back sessions with retries
    sess_rows, sess_json = [], {}
    for d in [0.8, 0.9, 0.95]:
        for rounds in [1, 3]:
            res, mean_r = simulate_sessions(100_000, BASE["a"], d, 0.02, BASE["a"], rounds, seed=int(d * 100) + rounds)
            sess_json.setdefault(str(d), {})[str(rounds)] = {**res, "mean_rounds": mean_r}
            sess_rows.append({"d": d, "Max rounds": rounds, "Correct": round(res["correct"], 4),
                              "Wrong submitted": round(res["wrong_submitted"], 4), "Escalated": round(res["escalated"], 4),
                              "Mean rounds": round(mean_r, 3)})
    out["E7"] = sess_json
    pd.DataFrame(sess_rows).to_csv(TAB / "table_sessions.csv", index=False)


    # ------------------------------------------------------------------ E6b capacity under non-exponential service
    cap_sim_rows, cap_sim_json = [], {}
    q90 = thr_json["medium (C_w=100)"]["0.9"]["q_at_tau_star"]
    def p_exceed_sim(N, lam, cpool, cv, seed):
        rate = N * lam * n_t * q90 / 3600.0
        sampler = exponential_sampler(60.0) if cv == 1.0 else lognormal_sampler(60.0, cv)
        w = simulate_mgc(rate, cpool, 150_000, sampler, seed=seed)[10_000:]
        return float(np.mean(w > T_SLA))
    lam = 2
    for cpool in [2, 3]:
        N_er = max_counters(cpool, lam, n_t, q90, 60.0, T_SLA, EPS)
        for cv in [1.0, 1.5, 2.5]:
            lo, hi = 1, int(N_er * 1.5) + 2
            while lo < hi:                                   # largest N with simulated P(W>t) <= eps
                mid = (lo + hi + 1) // 2
                if p_exceed_sim(mid, lam, cpool, cv, seed=11) <= EPS: lo = mid
                else: hi = mid - 1
            pe = p_exceed_sim(N_er, lam, cpool, cv, seed=11)
            cap_sim_json[f"pool{cpool}_cv{cv}"] = {"erlang_c_max_counters": N_er, "simulated_max_counters": lo, "p_exceed_at_erlang_N": pe}
            cap_sim_rows.append({"Interpreters in pool": cpool, "Service-time CV": cv, "Erlang C max counters": N_er,
                                 "Simulated max counters": lo, "Simulated P(W>20 s) at Erlang C limit": round(pe, 4)})
    out["E6b"] = cap_sim_json
    pd.DataFrame(cap_sim_rows).to_csv(TAB / "table_capacity_sim.csv", index=False)

    # ------------------------------------------------------------------ E8 sensitivity of Setu (P3) against read-back only (P2)
    rng = np.random.default_rng(seeds[4])
    sens_rows, sens_json = [], {}
    for a in [0.80, 0.90, 0.95]:
        yS, sS, cS = gen_turns(300_000, a, BASE["m"], rng)
        for d in [0.7, 0.9]:
            for ce in [2.0, 4.0, 10.0]:
                cm = CM.with_(d=d, C_e=ce)
                esc = (cS < tau_star(cm)).astype(float)
                r3, c3 = turn_outcomes(yS, esc, cm, readback=True)
                r2, c2 = turn_outcomes(yS, np.zeros_like(esc), cm, readback=True)
                sens_json[f"a{a}_d{d}_Ce{ce}"] = {"tau_star": tau_star(cm), "esc": float(esc.mean()), "res_P3": float(r3.mean()),
                                                  "cost_P3": float(c3.mean()), "res_P2": float(r2.mean()), "cost_P2": float(c2.mean())}
                sens_rows.append({"Base accuracy a": a, "d": d, "C_e": ce, "tau*": round(tau_star(cm), 3), "Escalation rate": round(float(esc.mean()), 3),
                                  "Residual P3": round(float(r3.mean()), 4), "Residual P2": round(float(r2.mean()), 4),
                                  "Cost P3": round(float(c3.mean()), 3), "Cost P2": round(float(c2.mean()), 3),
                                  "Cost reduction vs P2 (%)": round(100 * (1 - float(c3.mean()) / float(c2.mean())), 1)})
    out["E8"] = sens_json
    pd.DataFrame(sens_rows).to_csv(TAB / "table_sensitivity.csv", index=False)

    # ------------------------------------------------------------------ catalogue summary
    from setu.catalogue import load_catalogue, summary_table
    cat = load_catalogue()
    pd.DataFrame(summary_table(cat)).to_csv(TAB / "table_catalogue.csv", index=False)

    out["runtime_seconds"] = round(time.time() - t0, 1)
    with open(RES / "results.json", "w") as fh:
        json.dump(out, fh, indent=2)
    print("done in", out["runtime_seconds"], "s")


if __name__ == "__main__":
    main()
