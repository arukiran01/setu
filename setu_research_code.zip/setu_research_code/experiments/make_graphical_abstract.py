"""Draw the graphical abstract (2656 x 1062 px) from results/results.json.

Usage:  python -m experiments.make_graphical_abstract
Output: results/figures/graphical_abstract.png

The four headline numbers are computed from the simulation output, not typed in. The picture is drawn with
matplotlib patches and text only; no image-generation tool is used. Every label is checked against its box.
"""
from __future__ import annotations
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

from experiments.make_diagrams import Canvas, KINDS, INK, FIG

ROOT = Path(__file__).resolve().parents[1]
R = json.loads((ROOT / "results" / "results.json").read_text())

# ---- numbers from the results file ----------------------------------------------------------------------------
p = R["E2"]["1.0"]
mean = lambda k, f: p[k][f][0]
cost_gain = 1 - mean("P3", "cost") / mean("P2", "cost")          # Setu against read-back only
wrong_gain = 1 - mean("P3", "residual") / mean("P2", "residual")
esc = mean("P3", "escalation")
counters = R["E5"]["0.9"]["2"]["3"]["max_counters"]              # 2 transactions per counter-hour, pool of 3
assert abs(R["baseline"]["d"] - 0.9) < 1e-12 and R["E5_params"]["sla_wait_s"] == 20.0


def main():
    W, H = 13.28, 5.31
    c = Canvas(W, H)
    ax = c.ax
    t = ax.text(0.22, H - 0.42, "Setu: verified sign language access at public service counters",
                ha="left", va="center", fontsize=17.5, fontweight="bold", color="#2b2a28")
    c.fits(t, 0, H - 0.8, 9.0, H, 0.1, "title")

    # ---- flow ----------------------------------------------------------------------------------------------
    bw, bh, y = 1.9, 1.05, 2.95
    xs = [0.22, 2.42, 4.62, 6.82]
    boxes = [("Citizen signs", "Indian Sign Language", "system"),
             ("Trust gate", "calibrated confidence", "device"),
             ("Read-back", "citizen confirms", "device"),
             ("Submit", "verified request", "system")]
    for x, (a, b, k) in zip(xs, boxes):
        c.box(x, y, bw, bh, a, b, k, fs=14.5, fs_sub=11.6)
    for x in xs[:3]:
        c.arrow((x + bw, y + bh / 2), (x + bw + 0.3, y + bh / 2), lw=1.8)
    xd = xs[1] + bw / 2
    c.box(xd - 1.1, 0.95, 2.2, 1.05, "Remote interpreter", "sees skeleton only", "human", fs=14.0, fs_sub=11.6)
    c.arrow((xd, y), (xd, 2.0), lw=1.8)
    notes = ["Only low-confidence turns go to a human", "Raw video never leaves the counter unit",
             "Recognition, gate and read-back work offline"]
    for i, s in enumerate(notes):
        tt = ax.text(4.95, 1.78 - i * 0.42, s, ha="left", va="center", fontsize=12.6, color=INK)
        c.fits(tt, 4.9, 0.4, 9.2, 2.1, 0.0, s)       # starts right of the interpreter box, which ends at x = 4.47

    # ---- results column ------------------------------------------------------------------------------------
    ax.plot([9.35, 9.35], [0.3, H - 0.45], color="#c9c8c3", lw=1.4)
    h = ax.text(9.7, H - 0.85, "Simulation results", ha="left", va="center", fontsize=15, fontweight="bold", color="#2b2a28")
    c.fits(h, 9.5, H - 1.2, W, H - 0.5, 0.0, "results heading")
    rows = [(f"-{cost_gain * 100:.0f}%", "mean cost vs\nread-back alone"),
            (f"-{wrong_gain * 100:.0f}%", "wrong submissions vs\nread-back alone"),
            (f"{esc * 100:.1f}%", "of turns escalated\nto a human"),
            (f"{counters}", "counters served by a\npool of 3 interpreters")]
    for i, (big, small) in enumerate(rows):
        yy = H - 1.55 - i * 0.82
        a = ax.text(9.7, yy, big, ha="left", va="center", fontsize=26, fontweight="bold", color="#123e73")
        b = ax.text(11.05, yy, small, ha="left", va="center", fontsize=11.4, color="#2b2a28", linespacing=1.2)
        c.fits(a, 9.5, yy - 0.4, 11.0, yy + 0.4, 0.0, big)
        c.fits(b, 11.0, yy - 0.42, W, yy + 0.42, 0.0, small)
    f = ax.text(9.7, 0.45, "Design analysis under stated assumptions;\nfield validation protocol specified",
                ha="left", va="center", fontsize=9.8, color=INK, linespacing=1.25)
    c.fits(f, 9.5, 0.0, W, 0.85, 0.0, "footnote")

    c.fig.savefig(FIG / "graphical_abstract.png", dpi=200, facecolor="white")
    plt.close(c.fig)
    print(f"graphical abstract written: cost {cost_gain:.1%}, wrong {wrong_gain:.1%}, escalation {esc:.1%}, counters {counters}")


if __name__ == "__main__":
    main()
