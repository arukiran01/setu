"""Draw the two schematic figures of the manuscript (architecture and path of one turn).

Usage:  python -m experiments.make_diagrams
Outputs: results/figures/fig_architecture.{png,pdf}, results/figures/fig_flow.{png,pdf}

Both figures are drawn with matplotlib patches; no image-generation tool is used. Every label is measured
against its box after drawing, and the script stops with an error if a label does not fit.
"""
from __future__ import annotations
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Polygon

FIG = Path(__file__).resolve().parents[1] / "results" / "figures"
FIG.mkdir(parents=True, exist_ok=True)
plt.rcParams.update({"font.family": "sans-serif", "font.sans-serif": ["Inter", "DejaVu Sans"]})

KINDS = {   # fill, edge, title colour, subtitle colour
    "device": ("#e6f0fc", "#2a78d6", "#123e73", "#2a5a99"),
    "human": ("#fdece4", "#eb6834", "#8a3512", "#a8441a"),
    "system": ("#efeeea", "#7a7975", "#2b2a28", "#52514e"),
}
INK = "#52514e"


class Canvas:
    def __init__(self, w, h):
        self.fig = plt.figure(figsize=(w, h))
        self.ax = self.fig.add_axes([0, 0, 1, 1])
        self.ax.set_xlim(0, w); self.ax.set_ylim(0, h); self.ax.axis("off")
        self.fig.canvas.draw()
        self.r = self.fig.canvas.get_renderer()
        self.checks = []

    def fits(self, text_artist, x0, y0, x1, y1, pad=0.05, name=""):
        bb = text_artist.get_window_extent(self.r).transformed(self.ax.transData.inverted())
        ok = bb.x0 >= x0 + pad and bb.x1 <= x1 - pad and bb.y0 >= y0 + 0.02 and bb.y1 <= y1 - 0.02
        if not ok:
            raise ValueError(f"label '{name}' does not fit its box: text {bb.x0:.2f}-{bb.x1:.2f} x {bb.y0:.2f}-{bb.y1:.2f} "
                             f"box {x0:.2f}-{x1:.2f} x {y0:.2f}-{y1:.2f}")

    def box(self, x, y, w, h, title, sub=None, kind="device", fs=7.8, fs_sub=6.8, diamond=False):
        fill, edge, tc, sc = KINDS[kind]
        if diamond:
            pts = [(x + w / 2, y + h), (x + w, y + h / 2), (x + w / 2, y), (x, y + h / 2)]
            self.ax.add_patch(Polygon(pts, closed=True, fc=fill, ec=edge, lw=1.3, joinstyle="round"))
        else:
            self.ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0,rounding_size=0.07", fc=fill, ec=edge, lw=1.3))
        cx = x + w / 2
        if sub:
            t1 = self.ax.text(cx, y + h * 0.63, title, ha="center", va="center", fontsize=fs, fontweight="bold", color=tc)
            t2 = self.ax.text(cx, y + h * 0.28, sub, ha="center", va="center", fontsize=fs_sub, color=sc, linespacing=1.15)
            ts = [t1, t2]
        else:
            ts = [self.ax.text(cx, y + h / 2, title, ha="center", va="center", fontsize=fs, fontweight="bold", color=tc, linespacing=1.15)]
        for t in ts:
            if diamond:   # text must fit inside the inscribed rectangle of the diamond
                self.fits(t, x + w * 0.2, y + h * 0.18, x + w * 0.8, y + h * 0.82, 0.0, t.get_text())
            else:
                self.fits(t, x, y, x + w, y + h, 0.06, t.get_text())

    def arrow(self, p0, p1, ls="-", lw=1.2):
        self.ax.annotate("", xy=p1, xytext=p0, arrowprops=dict(arrowstyle="-|>", color=INK, lw=lw, ls=ls, shrinkA=0, shrinkB=0,
                                                             mutation_scale=9))

    def line(self, pts, lw=1.2):
        xs, ys = zip(*pts)
        self.ax.plot(xs, ys, color=INK, lw=lw, solid_capstyle="butt")

    def label(self, x, y, s, ha="left", va="center", fs=7.2, style="normal"):
        t = self.ax.text(x, y, s, ha=ha, va=va, fontsize=fs, color=INK, style=style)
        return t

    def save(self, name):
        self.fig.savefig(FIG / f"{name}.png", dpi=300, facecolor="white")
        self.fig.savefig(FIG / f"{name}.pdf", facecolor="white")
        plt.close(self.fig)


def architecture():
    c = Canvas(6.6, 3.55)
    ax = c.ax
    ax.add_patch(FancyBboxPatch((0.05, 2.0), 6.5, 1.5, boxstyle="round,pad=0,rounding_size=0.1", fc="white", ec="#7a7975", lw=1.1, ls=(0, (4, 3))))
    c.label(0.2, 3.32, "Counter unit (runs offline)", fs=8.2).set_fontweight("bold")
    xs = [0.2, 1.8, 3.4, 5.0]
    items = [("Perception", "Skeleton, speech"), ("Intent engine", "Intent and slots"), ("Trust gate", "Calibrated score"), ("Read-back", "Sign clips, icons, text")]
    for x, (t, s) in zip(xs, items):
        c.box(x, 2.12, 1.45, 0.88, t, s, "device")
    for x in xs[:3]:
        c.arrow((x + 1.45, 2.56), (x + 1.6, 2.56))
    # lower row
    c.box(0.2, 0.62, 2.55, 0.8, "Community learning loop", "Corrections become regional adapters", "human")
    c.box(3.2, 0.62, 1.7, 0.8, "Remote interpreter", "Sees skeleton only", "human")
    c.box(5.1, 0.62, 1.35, 0.8, "Counter application", "Existing systems", "system", fs=7.3)
    # arrows
    c.arrow((4.125, 2.12), (4.125, 1.42)); c.label(4.2, 1.77, "escalate")
    c.arrow((5.725, 2.12), (5.725, 1.42)); c.label(5.65, 1.77, "confirmed", ha="right")
    c.arrow((3.2, 1.02), (2.75, 1.02))
    c.arrow((2.2, 1.42), (2.2, 2.12)); c.label(2.12, 1.77, "adapter updates", ha="right")
    # privacy band
    ax.add_patch(FancyBboxPatch((0.05, 0.05), 6.5, 0.38, boxstyle="round,pad=0,rounding_size=0.07", fc="#efeeea", ec="#7a7975", lw=1.1))
    t = ax.text(3.3, 0.24, "Privacy boundary: raw video stays on the unit; only skeleton keypoints and metadata travel to the hub.",
                ha="center", va="center", fontsize=7.2, color="#2b2a28")
    c.fits(t, 0.05, 0.05, 6.55, 0.43, 0.08, "privacy")
    c.save("fig_architecture")


def flow():
    c = Canvas(6.6, 3.35)
    ax = c.ax
    w, h, step, x0, y = 0.86, 0.86, 1.12, 0.05, 1.75
    dx = 0.1                                   # diamonds are wider than boxes by 2*dx
    xs = [x0 + i * step for i in range(6)]
    c.box(xs[0], y, w, h, "Citizen signs", None, "system", fs=7.2)
    c.box(xs[1], y, w, h, "Proposal and\nconfidence", None, "device", fs=7.0)
    c.box(xs[2] - dx, y - 0.09, w + 2 * dx, h + 0.18, "Confidence\n\u2265 threshold?", None, "device", fs=6.9, diamond=True)
    c.box(xs[3], y, w, h, "Read-back", "Sign clips,\nicons, text", "device", fs=7.2, fs_sub=6.4)
    c.box(xs[4] - dx, y - 0.09, w + 2 * dx, h + 0.18, "Citizen\nconfirms?", None, "system", fs=6.9, diamond=True)
    c.box(xs[5], y, w, h, "Request\nsubmitted", None, "system", fs=7.0)
    ym = y + h / 2
    c.arrow((xs[0] + w, ym), (xs[1], ym))
    c.arrow((xs[1] + w, ym), (xs[2] - dx, ym))
    c.arrow((xs[2] + w + dx, ym), (xs[3], ym)); c.label(xs[2] + w + dx + 0.07, ym + 0.2, "yes", ha="center", fs=6.5)
    c.arrow((xs[3] + w, ym), (xs[4] - dx, ym))
    c.arrow((xs[4] + w + dx, ym), (xs[5], ym)); c.label(xs[4] + w + dx + 0.07, ym + 0.2, "yes", ha="center", fs=6.5)
    # escalation branch (below the first decision)
    xd = xs[2] + w / 2
    c.box(xd - 0.62, 0.35, 1.24, 0.7, "Interpreter resolves", "Sees skeleton only", "human", fs=7.0, fs_sub=6.5)
    c.arrow((xd, y - 0.09), (xd, 1.05)); c.label(xd + 0.07, 1.4, "no", fs=6.8)
    xr_b = xs[3] + w / 2
    c.line([(xd + 0.62, 0.7), (xr_b, 0.7)]); c.arrow((xr_b, 0.7), (xr_b, y))
    c.label((xd + 0.62 + xr_b) / 2, 0.57, "corrected", ha="center", va="top", fs=6.8)
    # retry loop (above)
    xr = xs[4] + w / 2
    c.line([(xr, y + h + 0.09), (xr, 3.0), (xs[0] + w / 2, 3.0)]); c.arrow((xs[0] + w / 2, 3.0), (xs[0] + w / 2, y + h))
    t = ax.text(xr - 0.1, 3.06, "no: citizen signs again", ha="right", va="bottom", fontsize=6.9, color=INK)
    c.fits(t, 0, 3.0, 6.6, 3.35, 0.0, "retry")
    c.save("fig_flow")


if __name__ == "__main__":
    architecture()
    flow()
    print("diagrams written to", FIG)
