"""Create SYNTHETIC demo CSVs so the evaluation pipeline can be tested end to end.

THESE DATA ARE SYNTHETIC. They are random numbers drawn from simple distributions. They are
not measurements, must never be reported as results, and exist only to exercise evaluate_real.py.
"""
from __future__ import annotations
from pathlib import Path
import numpy as np
import pandas as pd
from setu.calibration import logit, sigmoid


def make(out_dir="eval/demo_data", n_turns=2000, n_participants=12, seed=7):
    rng = np.random.default_rng(seed)
    out = Path(out_dir); out.mkdir(parents=True, exist_ok=True)
    y = (rng.random(n_turns) < 0.88).astype(int)
    s = rng.normal((2 * y - 1) * 1.0, 1.0)
    conf = sigmoid(2.0 * (2 * s + logit(0.88)))            # deliberately over-confident
    esc = (conf < 0.62).astype(int)
    rb = np.ones(n_turns, dtype=int)
    wrong_after = np.where(esc == 1, rng.random(n_turns) > 0.99, y == 0)
    rejected = np.where(wrong_after, rng.random(n_turns) < 0.9, rng.random(n_turns) < 0.02).astype(int)
    final_correct = np.where(wrong_after & (rejected == 0), 0, 1)
    turns = pd.DataFrame({"turn_id": range(n_turns), "session_id": rng.integers(0, 400, n_turns),
                          "counter_type": rng.choice(["hospital_opd", "meeseva_csc", "gram_panchayat"], n_turns),
                          "risk_class": rng.choice(["low", "medium", "high"], n_turns, p=[.3, .5, .2]),
                          "split": np.where(rng.random(n_turns) < 0.3, "val", "test"),
                          "y_correct": y, "confidence_raw": conf, "escalated": esc, "readback_shown": rb,
                          "shown_correct": (~wrong_after).astype(int), "readback_rejected": rejected, "final_correct": final_correct,
                          "interpreter_seconds": np.where(esc == 1, rng.lognormal(np.log(55), 0.5, n_turns), np.nan)})
    turns.to_csv(out / "turns.csv", index=False)
    rows = []
    for p in range(n_participants):
        for t in range(6):
            base = rng.lognormal(np.log(150), 0.3)
            rows.append({"participant_id": p, "task_id": t, "condition": "notes", "duration_s": base, "success": 1})
            rows.append({"participant_id": p, "task_id": t, "condition": "setu", "duration_s": base * rng.uniform(0.5, 0.9), "success": 1})
    pd.DataFrame(rows).to_csv(out / "sessions.csv", index=False)
    sus = pd.DataFrame({f"q{i}": rng.integers(3, 6, n_participants) if i % 2 else rng.integers(1, 3, n_participants) for i in range(1, 11)})
    sus.insert(0, "participant_id", range(n_participants))
    sus.to_csv(out / "sus.csv", index=False)
    return out


if __name__ == "__main__":
    print("SYNTHETIC demo data written to", make())
