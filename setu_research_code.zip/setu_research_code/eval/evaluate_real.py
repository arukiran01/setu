"""Evaluate REAL pilot or benchmark logs and produce the manuscript's empirical tables.

Inputs (CSV, see data/schemas/README.md):
  turns.csv     one row per interaction turn
  sessions.csv  one row per task attempt (Setu vs handwritten-note baseline)
  sus.csv       one row per participant (System Usability Scale items q1..q10, each 1..5)

Usage:
  python -m eval.evaluate_real --turns turns.csv --sessions sessions.csv --sus sus.csv --out results_real
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

from setu.calibration import PlattScaler, brier, ece, logit, nll


def wilson(k: int, n: int, z: float = 1.96):
    if n == 0:
        return (np.nan, np.nan, np.nan)
    p = k / n
    den = 1 + z * z / n
    centre = (p + z * z / (2 * n)) / den
    half = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
    return (p, centre - half, centre + half)


def sus_score(items) -> float:
    """System Usability Scale (Brooke, 1996): odd items contribute (x-1), even items (5-x); sum x 2.5."""
    x = np.asarray(items, dtype=float)
    odd = x[0::2] - 1
    even = 5 - x[1::2]
    return float((odd.sum() + even.sum()) * 2.5)


def bootstrap_ci(x, stat=np.median, n_boot=5000, seed=0):
    rng = np.random.default_rng(seed)
    x = np.asarray(x, dtype=float)
    boots = [stat(rng.choice(x, size=len(x), replace=True)) for _ in range(n_boot)]
    return float(stat(x)), float(np.percentile(boots, 2.5)), float(np.percentile(boots, 97.5))


def turn_metrics(turns: pd.DataFrame) -> dict:
    out = {"n_turns": int(len(turns))}
    y = turns["y_correct"].to_numpy()
    out["proposal_accuracy"] = wilson(int(y.sum()), len(y))
    conf = turns["confidence_raw"].to_numpy()
    if "split" in turns.columns and {"val", "test"} <= set(turns["split"].unique()):
        val, test = turns[turns.split == "val"], turns[turns.split == "test"]
    else:
        val = test = turns
    ps = PlattScaler().fit(logit(val["confidence_raw"].to_numpy()), val["y_correct"].to_numpy())
    cal = ps.transform(logit(test["confidence_raw"].to_numpy()))
    yt = test["y_correct"].to_numpy()
    out["calibration"] = {"ece_raw": ece(yt, test["confidence_raw"].to_numpy()), "ece_platt": ece(yt, cal),
                          "brier_raw": brier(yt, test["confidence_raw"].to_numpy()), "brier_platt": brier(yt, cal),
                          "nll_raw": nll(yt, test["confidence_raw"].to_numpy()), "nll_platt": nll(yt, cal),
                          "platt_a": ps.a, "platt_b": ps.b,
                          "note": "Platt scaler fitted on the validation split when a split column is present."}
    out["escalation_rate"] = wilson(int(turns["escalated"].sum()), len(turns))
    rb = turns[turns["readback_shown"] == 1]
    wrong = rb[rb["shown_correct"] == 0]      # read-backs whose content was wrong (after any interpreter correction)
    right = rb[rb["shown_correct"] == 1]
    out["readback_detection_d"] = wilson(int(wrong["readback_rejected"].sum()), len(wrong))
    out["readback_false_reject_f"] = wilson(int(right["readback_rejected"].sum()), len(right))
    out["residual_wrong_submission"] = wilson(int((turns["final_correct"] == 0).sum()), len(turns))
    if "interpreter_seconds" in turns.columns:
        esc = turns[turns["escalated"] == 1]["interpreter_seconds"].dropna()
        out["interpreter_service_seconds"] = {"mean": float(esc.mean()) if len(esc) else np.nan,
                                              "cv": float(esc.std() / esc.mean()) if len(esc) > 1 else np.nan}
    if "risk_class" in turns.columns:
        out["by_risk_class"] = {r: {"n": int(len(g)), "accuracy": float(g.y_correct.mean()),
                                    "escalation": float(g.escalated.mean()),
                                    "residual": float((g.final_correct == 0).mean())}
                                for r, g in turns.groupby("risk_class")}
    return out


def task_time_comparison(sessions: pd.DataFrame) -> dict:
    piv = sessions.pivot_table(index=["participant_id", "task_id"], columns="condition", values="duration_s", aggfunc="mean").dropna()
    if not {"setu", "notes"} <= set(piv.columns) or len(piv) < 3:
        return {"error": "need paired setu and notes durations for at least 3 participant-task pairs"}
    diff = piv["notes"] - piv["setu"]
    w = stats.wilcoxon(piv["notes"], piv["setu"], alternative="two-sided")
    n = len(diff)
    ranks = stats.rankdata(np.abs(diff[diff != 0]))
    signs = np.sign(diff[diff != 0])
    rbc = float((ranks[signs > 0].sum() - ranks[signs < 0].sum()) / ranks.sum()) if len(ranks) else np.nan
    med = bootstrap_ci(diff.to_numpy())
    rel = float(1 - piv["setu"].median() / piv["notes"].median())
    return {"pairs": int(n), "median_notes_s": float(piv["notes"].median()), "median_setu_s": float(piv["setu"].median()),
            "median_reduction_s_ci": med, "relative_reduction_of_medians": rel,
            "wilcoxon_statistic": float(w.statistic), "wilcoxon_p": float(w.pvalue), "rank_biserial": rbc}


def sus_summary(sus: pd.DataFrame) -> dict:
    cols = [f"q{i}" for i in range(1, 11)]
    scores = sus[cols].apply(lambda r: sus_score(r.to_numpy()), axis=1).to_numpy()
    m, lo, hi = bootstrap_ci(scores, stat=np.mean)
    return {"n": int(len(scores)), "mean": m, "ci95": [lo, hi], "median": float(np.median(scores)),
            "scores": scores.tolist()}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--turns", required=True)
    ap.add_argument("--sessions", required=True)
    ap.add_argument("--sus", required=True)
    ap.add_argument("--out", default="results_real")
    a = ap.parse_args()
    out_dir = Path(a.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    res = {"turns": turn_metrics(pd.read_csv(a.turns)),
           "task_time": task_time_comparison(pd.read_csv(a.sessions)),
           "sus": sus_summary(pd.read_csv(a.sus))}
    with open(out_dir / "empirical_results.json", "w") as fh:
        json.dump(res, fh, indent=2, default=float)
    print(json.dumps(res, indent=2, default=float)[:2000])


if __name__ == "__main__":
    main()
