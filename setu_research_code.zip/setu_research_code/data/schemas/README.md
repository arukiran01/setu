# Data schemas for the real evaluation

Collect these files in the pilot and benchmark studies. Column names are used by `eval/evaluate_real.py`.

## turns.csv (one row per interaction turn)
| column | type | meaning |
|---|---|---|
| turn_id | int | unique id |
| session_id | int | transaction id |
| counter_type | str | hospital_opd, meeseva_csc, gram_panchayat, bank_post |
| risk_class | str | low, medium, high (from the catalogue) |
| split | str | optional: val or test (calibration is fitted on val, reported on test) |
| y_correct | 0/1 | 1 if the system's first proposal (intent and all slots) matched the ground truth |
| confidence_raw | float | model probability that the proposal is fully correct, before calibration |
| escalated | 0/1 | 1 if the turn was sent to the interpreter |
| readback_shown | 0/1 | 1 if a read-back was shown |
| shown_correct | 0/1 | 1 if the content shown in the read-back was correct (after any interpreter correction) |
| readback_rejected | 0/1 | 1 if the citizen rejected the read-back |
| final_correct | 0/1 | 1 if the submitted request matched the ground truth |
| interpreter_seconds | float | interpreter handling time for escalated turns |

## sessions.csv (one row per task attempt)
participant_id, task_id, condition (setu or notes), duration_s, success (0/1)

## sus.csv (one row per participant)
participant_id, q1 ... q10 (System Usability Scale responses, 1 to 5, standard item order)

Ground truth for `y_correct` and `final_correct` is fixed before the session by a scripted task card, so
the intended request is known. Do not store video, face images or names. Use pseudonymous participant ids.
