"""Samavesh Setu: confidence-gated, read-back-verified access layer (analysis code)."""
__version__ = "1.0.0"
