"""Trust gate: cost model, closed-form threshold, and risk-tiered thresholds.

Notation (see manuscript Section 4):
  c    calibrated probability that the proposed interpretation of a turn is fully correct
  d    probability that the citizen detects an incorrect read-back
  C_w  cost of a wrong request being submitted
  C_r  cost of a retry after a caught error
  C_e  cost of escalating one turn to a remote interpreter
  C_rb cost of showing a read-back
  a_h  probability that the interpreter's corrected interpretation is right
"""
from __future__ import annotations
from dataclasses import dataclass, replace


@dataclass(frozen=True)
class CostModel:
    C_w: float = 100.0
    C_r: float = 1.0
    C_e: float = 4.0
    C_rb: float = 0.5
    a_h: float = 0.99
    d: float = 0.90

    def with_(self, **kw) -> "CostModel":
        return replace(self, **kw)


def K(cm: CostModel) -> float:
    """Expected cost of an incorrect interpretation passing through read-back."""
    return cm.d * cm.C_r + (1.0 - cm.d) * cm.C_w


def tau_star(cm: CostModel) -> float:
    """Closed-form cost-optimal escalation threshold (Proposition 1): a_h - C_e / K."""
    t = cm.a_h - cm.C_e / K(cm)
    return float(min(1.0, max(0.0, t)))


def expected_cost_accept(c, cm: CostModel):
    return cm.C_rb + (1.0 - c) * K(cm)


def expected_cost_escalate(cm: CostModel) -> float:
    return cm.C_e + cm.C_rb + (1.0 - cm.a_h) * K(cm)


def decide(c: float, tau: float) -> str:
    """Return 'escalate' when confidence is below the threshold, else 'accept'."""
    return "escalate" if c < tau else "accept"


def risk_tiered_thresholds(risk_costs: dict, cm: CostModel) -> dict:
    """Threshold per risk class, where risk classes differ in the wrong-submission cost C_w."""
    return {name: tau_star(cm.with_(C_w=cw)) for name, cw in risk_costs.items()}


def residual_error_rate(c, escalated, cm: CostModel):
    """Mean probability that a wrong request is submitted, given per-turn confidences."""
    import numpy as np
    c = np.asarray(c, dtype=float)
    escalated = np.asarray(escalated, dtype=bool)
    p_wrong = np.where(escalated, 1.0 - cm.a_h, 1.0 - c)
    return float(np.mean(p_wrong * (1.0 - cm.d)))
