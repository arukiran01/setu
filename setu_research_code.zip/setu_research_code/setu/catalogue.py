"""Service intent catalogue loader and validator."""
from __future__ import annotations
import json
from pathlib import Path

DEFAULT_PATH = Path(__file__).resolve().parents[1] / "data" / "service_intent_catalogue.json"
RISK_CLASSES = ("low", "medium", "high")


def load_catalogue(path=DEFAULT_PATH) -> dict:
    with open(path, "r", encoding="utf-8") as fh:
        cat = json.load(fh)
    validate_catalogue(cat)
    return cat


def validate_catalogue(cat: dict) -> None:
    seen = set()
    for ctype, block in cat["counter_types"].items():
        for it in block["intents"]:
            iid = it["id"]
            if iid in seen:
                raise ValueError(f"duplicate intent id {iid}")
            seen.add(iid)
            if it["risk_class"] not in RISK_CLASSES:
                raise ValueError(f"{iid}: bad risk class")
            if it["risk_class"] != "low" and not it["readback_required"]:
                raise ValueError(f"{iid}: read-back must be required for non-low risk")
            for s in it["slots"]:
                if "name" not in s or "values" not in s or not s["values"]:
                    raise ValueError(f"{iid}: malformed slot {s}")


def summary_table(cat: dict):
    """Rows: counter type, number of intents, per-risk counts, mean slots per intent."""
    rows = []
    for ctype, block in cat["counter_types"].items():
        its = block["intents"]
        rows.append({
            "counter_type": ctype,
            "intents": len(its),
            "low": sum(i["risk_class"] == "low" for i in its),
            "medium": sum(i["risk_class"] == "medium" for i in its),
            "high": sum(i["risk_class"] == "high" for i in its),
            "mean_slots": round(sum(len(i["slots"]) for i in its) / len(its), 2),
        })
    return rows
