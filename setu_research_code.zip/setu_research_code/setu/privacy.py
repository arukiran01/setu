"""Relay payload validation: only skeleton keypoints and metadata may leave the counter unit."""
from __future__ import annotations
import numpy as np

ALLOWED_KEYS = {"session_token", "timestamp", "landmarks", "intent_candidates", "counter_type"}
FORBIDDEN_KEYS = {"frame", "frames", "video", "image", "images", "audio", "face_crop", "raw"}


def validate_relay_payload(payload: dict) -> None:
    """Raise ValueError unless the payload contains only allowed, non-raw fields."""
    keys = set(payload)
    bad = keys & FORBIDDEN_KEYS
    if bad:
        raise ValueError(f"forbidden raw-media fields in relay payload: {sorted(bad)}")
    extra = keys - ALLOWED_KEYS
    if extra:
        raise ValueError(f"unexpected fields in relay payload: {sorted(extra)}")
    lm = payload.get("landmarks")
    if lm is not None:
        arr = np.asarray(lm, dtype=float)
        if arr.ndim != 3 or arr.shape[-1] not in (2, 3):
            raise ValueError("landmarks must have shape (frames, joints, 2 or 3)")
