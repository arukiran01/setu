"""Read-back verification protocol: closed forms and a session simulator."""
from __future__ import annotations
import numpy as np


def residual_wrong_submission(p_wrong: float, d: float) -> float:
    """P(wrong request submitted) after one read-back round: p_wrong * (1 - d)."""
    return p_wrong * (1.0 - d)


def simulate_session(p_correct_first: float, d: float, f: float, p_correct_retry: float,
                     max_rounds: int, rng: np.random.Generator):
    """Simulate one read-back session with retries.

    Each round the system proposes an interpretation. A correct proposal is confirmed with
    probability 1 - f (f is the false-reject rate). A wrong proposal is rejected with
    probability d, otherwise it is confirmed by mistake. A rejection triggers a retry with
    a fresh proposal that is correct with probability p_correct_retry. After max_rounds
    rejections the session is escalated to a human.

    Returns (outcome, rounds) with outcome in {"correct", "wrong_submitted", "escalated"}.
    """
    p = p_correct_first
    for r in range(1, max_rounds + 1):
        correct = rng.random() < p
        if correct:
            if rng.random() < 1.0 - f:
                return "correct", r
        else:
            if rng.random() >= d:
                return "wrong_submitted", r
        p = p_correct_retry
    return "escalated", max_rounds


def simulate_sessions(n: int, p_correct_first: float, d: float, f: float, p_correct_retry: float,
                      max_rounds: int, seed: int = 0):
    rng = np.random.default_rng(seed)
    out = {"correct": 0, "wrong_submitted": 0, "escalated": 0}
    rounds = np.zeros(n)
    for i in range(n):
        o, r = simulate_session(p_correct_first, d, f, p_correct_retry, max_rounds, rng)
        out[o] += 1
        rounds[i] = r
    return {k: v / n for k, v in out.items()}, float(rounds.mean())
