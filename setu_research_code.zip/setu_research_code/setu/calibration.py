"""Confidence calibration utilities (Platt scaling, temperature scaling, ECE, Brier, NLL)."""
from __future__ import annotations
import numpy as np
from scipy.optimize import minimize

EPS = 1e-12


def sigmoid(z):
    z = np.asarray(z, dtype=float)
    return 1.0 / (1.0 + np.exp(-np.clip(z, -60, 60)))


def logit(p):
    p = np.clip(np.asarray(p, dtype=float), EPS, 1 - EPS)
    return np.log(p / (1 - p))


def nll(y, p):
    """Mean negative log-likelihood of binary outcomes y under probabilities p."""
    y = np.asarray(y, dtype=float)
    p = np.clip(np.asarray(p, dtype=float), EPS, 1 - EPS)
    return float(-np.mean(y * np.log(p) + (1 - y) * np.log(1 - p)))


def brier(y, p):
    y = np.asarray(y, dtype=float)
    return float(np.mean((np.asarray(p, dtype=float) - y) ** 2))


def reliability_table(y, p, n_bins: int = 15):
    """Equal-width reliability table: bin centre, mean confidence, accuracy, count."""
    y = np.asarray(y, dtype=float)
    p = np.asarray(p, dtype=float)
    edges = np.linspace(0.0, 1.0, n_bins + 1)
    idx = np.clip(np.digitize(p, edges[1:-1], right=False), 0, n_bins - 1)
    centres, conf, acc, cnt = [], [], [], []
    for b in range(n_bins):
        m = idx == b
        centres.append((edges[b] + edges[b + 1]) / 2)
        cnt.append(int(m.sum()))
        conf.append(float(p[m].mean()) if m.any() else np.nan)
        acc.append(float(y[m].mean()) if m.any() else np.nan)
    return np.array(centres), np.array(conf), np.array(acc), np.array(cnt)


def ece(y, p, n_bins: int = 15):
    """Expected calibration error (Naeini et al., 2015) with equal-width bins."""
    _, conf, acc, cnt = reliability_table(y, p, n_bins)
    n = cnt.sum()
    valid = cnt > 0
    return float(np.sum(cnt[valid] / n * np.abs(acc[valid] - conf[valid])))


class TemperatureScaler:
    """One-parameter scaling of logits: p = sigmoid(logit / T)."""

    def __init__(self):
        self.T = 1.0

    def fit(self, logits, y):
        logits = np.asarray(logits, dtype=float)

        def obj(logT):
            return nll(y, sigmoid(logits / np.exp(logT[0])))

        r = minimize(obj, x0=[0.0], method="L-BFGS-B", bounds=[(-4, 4)])
        self.T = float(np.exp(r.x[0]))
        return self

    def transform(self, logits):
        return sigmoid(np.asarray(logits, dtype=float) / self.T)


class PlattScaler:
    """Two-parameter scaling of logits: p = sigmoid(a * logit + b) (Platt, 1999)."""

    def __init__(self):
        self.a, self.b = 1.0, 0.0

    def fit(self, logits, y):
        logits = np.asarray(logits, dtype=float)

        def obj(w):
            return nll(y, sigmoid(w[0] * logits + w[1]))

        r = minimize(obj, x0=[1.0, 0.0], method="L-BFGS-B")
        self.a, self.b = float(r.x[0]), float(r.x[1])
        return self

    def transform(self, logits):
        return sigmoid(self.a * np.asarray(logits, dtype=float) + self.b)
