import json
import math
import unittest

import numpy as np

from setu.calibration import PlattScaler, TemperatureScaler, ece, logit, sigmoid
from setu.catalogue import load_catalogue
from setu.privacy import validate_relay_payload
from setu.queueing import erlang_c, exponential_sampler, p_wait_exceeds, simulate_mgc
from setu.trust_gate import CostModel, K, expected_cost_accept, expected_cost_escalate, tau_star


class TestTrustGate(unittest.TestCase):
    def test_tau_star_is_indifference_point(self):
        cm = CostModel()
        t = tau_star(cm)
        self.assertAlmostEqual(expected_cost_accept(t, cm), expected_cost_escalate(cm), places=9)

    def test_tau_star_decreases_with_detection(self):
        vals = [tau_star(CostModel(d=d)) for d in (0.0, 0.5, 0.9, 0.95)]
        self.assertTrue(all(a > b for a, b in zip(vals, vals[1:])))

    def test_k_bounds(self):
        cm = CostModel(d=1.0)
        self.assertAlmostEqual(K(cm), cm.C_r)
        self.assertAlmostEqual(K(CostModel(d=0.0)), cm.C_w)


class TestCalibration(unittest.TestCase):
    def test_scalers_recover_overconfidence(self):
        rng = np.random.default_rng(0)
        n, a, m, kappa = 40000, 0.9, 1.0, 2.5
        y = (rng.random(n) < a).astype(int)
        s = rng.normal((2 * y - 1) * m, 1.0)
        ell = kappa * (2 * m * s + logit(a))
        self.assertGreater(ece(y, sigmoid(ell)), 0.03)
        ts = TemperatureScaler().fit(ell, y)
        self.assertAlmostEqual(ts.T, kappa, delta=0.15)
        ps = PlattScaler().fit(ell, y)
        self.assertLess(ece(y, ps.transform(ell)), 0.01)


class TestQueueing(unittest.TestCase):
    def test_erlang_c_single_server(self):
        self.assertAlmostEqual(erlang_c(0.5, 1), 0.5, places=9)

    def test_des_matches_erlang_c(self):
        c, A, ES = 3, 2.1, 60.0
        w = simulate_mgc(A / ES, c, 200000, exponential_sampler(ES), seed=1)[10000:]
        self.assertAlmostEqual(float(np.mean(w > 20.0)), p_wait_exceeds(A, c, ES, 20.0), delta=0.02)


class TestPrivacyAndCatalogue(unittest.TestCase):
    def test_relay_rejects_raw_media(self):
        with self.assertRaises(ValueError):
            validate_relay_payload({"session_token": "x", "video": b"..."})
        validate_relay_payload({"session_token": "x", "timestamp": 0.0, "landmarks": np.zeros((5, 75, 3))})

    def test_catalogue_is_valid(self):
        cat = load_catalogue()
        n = sum(len(b["intents"]) for b in cat["counter_types"].values())
        self.assertEqual(n, 27)


if __name__ == "__main__":
    unittest.main()
