# Setu analysis code

Code, data and scripts behind the manuscript "Setu: a calibrated-escalation and read-back architecture for sign language access at public service counters". It implements the trust gate, calibration, read-back analysis, interpreter-hub queueing model, a privacy validator for the relay payload, and the evaluation scripts for real data.

## Important

All numbers produced by `experiments/run_all.py` are **simulation results under stated assumptions**. They are not measurements from signers or counters. `eval/demo_data/` contains **synthetic** data used only to test the evaluation pipeline. Never report it as results.

## Layout

| Path | Purpose |
|---|---|
| `setu/calibration.py` | Platt and temperature scaling, ECE, Brier, NLL, reliability table |
| `setu/trust_gate.py` | Cost model, closed-form threshold `tau* = a_h - C_e / K`, risk-tiered thresholds |
| `setu/readback.py` | Read-back session simulator with retries |
| `setu/queueing.py` | Erlang C, capacity search, FIFO M/G/c discrete-event simulator |
| `setu/privacy.py` | Validator that rejects raw media in the relay payload |
| `setu/catalogue.py` | Loader and validator for the intent catalogue |
| `data/service_intent_catalogue.json` | 27 administrative intents, 4 counter types, risk classes, slots |
| `data/schemas/README.md` | CSV schemas for the real studies |
| `experiments/run_all.py` | Reproduces every simulation table and the data figures (reliability, threshold and frontier, capacity and queueing validation, read-back effect) |
| `experiments/make_diagrams.py` | Draws the architecture and path-of-one-turn diagrams with matplotlib (no image-generation tool) |
| `experiments/make_graphical_abstract.py` | Draws the graphical abstract; the four headline numbers are read from `results/results.json` |
| `eval/evaluate_real.py` | Computes the empirical quantities listed in Table 8 of the manuscript from real logs (accuracy, ECE, d, f, task time, SUS) |
| `eval/make_demo_data.py` | Writes synthetic demo CSVs for pipeline testing |
| `tests/test_core.py` | Unit tests |
| `results/` | Outputs of the last run: `results.json`, `tables/*.csv`, `figures/*.png|pdf` |

## Run

```
pip install -r requirements.txt
python -m unittest discover -s tests -t .
python -m experiments.run_all
python -m experiments.make_diagrams
python -m experiments.make_graphical_abstract
python -m eval.make_demo_data
python -m eval.evaluate_real --turns eval/demo_data/turns.csv --sessions eval/demo_data/sessions.csv --sus eval/demo_data/sus.csv --out results_demo
```

Seeds are fixed (`SEED = 20261113`). `run_all` takes about 11 seconds on one core.

## Using your own data

Collect `turns.csv`, `sessions.csv` and `sus.csv` as described in `data/schemas/README.md`, then run `python -m eval.evaluate_real` with your files. Replace the assumed parameters in `experiments/run_all.py` (`BASE`, `CM`, and the queueing parameters) with your measured values and re-run to update the simulation section.

## Licence

MIT. See `LICENSE`.
